const apiUrl = "http://127.0.0.1:8080/users.json"; // Adjust if port is different

async function fetchEmployees(url) {
    try {
        const res = await fetch(url);
        const data = await res.json();
        if (Array.isArray(data)) showCards(data);
    } catch (err) {
        console.error("Error fetching:", err);
    } finally {
        document.getElementById("loading").style.display = "none";
    }
}

function showCards(data) {
    const container = document.getElementById("card-container");
    data.forEach(emp => {
        const card = document.createElement("div");
        card.className = "card";
        card.innerHTML = `
            <h3>${emp.Name}</h3>
            <p><strong>Office:</strong> ${emp.Office}</p>
            <p><strong>Position:</strong> ${emp.Position}</p>
            <p><strong>Salary:</strong> ₹${emp.Salary}</p>
        `;
        container.appendChild(card);
    });
}

window.onload = () => fetchEmployees(apiUrl);
