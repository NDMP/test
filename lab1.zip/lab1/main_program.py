# Corrected imports (assuming module names are valid)
import data_loader
import data_processor
import data_visualizer
import data_analyzer

# Load data
data = data_loader.load_data('student_scores.csv')

if data is not None:
    # Calculate averages
    averages = data_processor.calculate_averages(data)
    print("Average Scores:", averages)

    # Plot averages
    data_visualizer.plot_averages(averages)

    # Get scores for a specific student
    student_name = "Alice"
    scores = data_processor.get_student_scores(data, student_name)

    if scores is not None:
        print(f"Scores for {student_name}: Math={scores[0]}, Science={scores[1]}, English={scores[2]}")

        # Perform t-test between Math and Science scores
        t_stat, p_value = data_analyzer.ttest_between_subjects(data, 'Math', 'Science')
        print(f"T-test between Math and Science: t_stat={t_stat}, p_value={p_value}")

        # Evaluate statistical significance
        if p_value < 0.05:
            print("There is a statistically significant difference between Math and Science scores.")
        else:
            print("No statistically significant difference between Math and Science scores.")
