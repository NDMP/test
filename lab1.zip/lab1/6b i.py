# Creating an empty tuple
empty_tuple = ()
print("Empty tuple: ", empty_tuple)
# Creating tuple having integers
int_tuple = (41, 36, 48, 510, 612, 714)
print("Tuple with integers: ", int_tuple)
# Creating a tuple having objects of different data types
mixed_tuple = (42, "Hai world", 29.3)
print("Tuple with different data types: ", mixed_tuple)
# Creating a nested tuple
nested_tuple = ("Python", {'name': 'abc', 'age': 20, 'sal':200000}, (45, 33, 25, 56))
print("A nested tuple: ", nested_tuple)