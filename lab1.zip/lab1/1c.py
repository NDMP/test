#Distance between two points
print("Enter coordinates for Point 1 : ")
x1=int(input("enter x1 : "))
x2=int(input("enter x2 : "))
print("Enter coordinates for Point 2 : ")
y1=int(input("enter y1 : "))
y2=int(input("enter y2 : "))
result= ((((x2 - x1 )**2) + ((y2-y1)**2) )**0.5)
print("distance between",(x1,x2),"and",(y1,y2),"is : ",result)
