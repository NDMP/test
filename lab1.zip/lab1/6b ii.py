# Python program to show how slicing works in Python tuples
# Creating a tuple
tuple_ = ("Django", "Flask", "J2E", "OOPS", "Inheritance", "Class")
# Using slicing to access elements of the tuple
print("Elements between indices 1 and 3: ", tuple_[1:3])
# Using negative indexing in slicing
print("Elements between indices 0 and -4: ", tuple_[:-4])
# Printing the entire tuple by using the default start and end values.
print("Entire tuple: ", tuple_[:])